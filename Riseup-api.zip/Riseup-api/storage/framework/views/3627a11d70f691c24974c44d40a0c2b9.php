<?php $__env->startSection('title','Update Category'); ?>

<?php $__env->startSection('content'); ?>

<div class="content bg-white p-2 px-4">
    <div class="mt-5">
        <form enctype="multipart/form-data" action="<?php echo e(route('categories.update', $category->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group mb-5">
                <label for="name" class="mb-2">Category</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Nama Category" value="<?php echo e($category->name); ?>">
            </div>
            <button type="submit" class="btn btn-primary-green">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Riseup-api\resources\views/pages/category/edit.blade.php ENDPATH**/ ?>