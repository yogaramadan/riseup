<?php $__env->startSection('title','Create Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="content bg-white p-2 px-4">
    <div class=" mt-5">
        <form enctype="multipart/form-data" action="<?php echo e(route('categories.store')); ?>" method="post">

            <?php echo csrf_field(); ?>
            <div class="form-group  mb-5">
                <label for="name" class="mb-2">Category</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Nama Category">
            </div>
            <button type=" submit" class="btn btn-primary-green ">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Riseup-api\resources\views/pages/category/create.blade.php ENDPATH**/ ?>