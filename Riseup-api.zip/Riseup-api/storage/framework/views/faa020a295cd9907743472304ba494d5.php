<?php $__env->startSection('title', 'Data Fundings'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <div class="content">
        <div class="mt-5">
            <a href=<?php echo e(route('funding.create')); ?> class="btn btn-primary-green mb-3">Tambah Funding</a>
            <h1></h1>
            <table id="table" class="table table-hover" style="width:100%">
                <thead>
                    <tr>
                                                <th>Image</th>

                        <th>Title</th>
                        <th>Fund Raise Use</th>
                        <th>UKM</th>
                        <th>Target Amount</th>
                        <th>Current Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $fundings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                               <td><img src="<?php echo e(env('OSS_DOMAIN_PUBLIC')); ?>/images/<?php echo e($funding->image); ?>" alt="image articles "
                                    width="70" height="70" />
                            <td><?php echo e($funding->title); ?></td>
                            <td><?php echo e($funding->fund_raise_use); ?></td>
                            <td><?php echo e($funding->ukm->name); ?></td>

                            <td><?php echo e($funding->target_amount); ?></td>
                            <td><?php echo e($funding->current_amount); ?></td>
                            <td><?php echo e($funding->status ? 'Diterima' : 'Ditolak'); ?></td>
                            <td class="d-flex gap-2">
                                <a href="<?php echo e(route('funding.edit', $funding)); ?>" class="btn btn-green text-white">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('funding.destroy', $funding)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Riseup-api\resources\views/pages/funding/index.blade.php ENDPATH**/ ?>